package com.example.laboratorio3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_fourth.*
import kotlinx.android.synthetic.main.activity_third.*
import kotlinx.android.synthetic.main.activity_third.txt_virus_symptoms_indications

class FourthActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fourth)


        var text_Indications: String = "Las personas que presenten alguno de los siguientes síntomas respiratorios (fiebre, tos y sensación de falta de aire) y vivan o hayan estado en los 14 días previos en una zona de transmisión comunitaria, o hayan tenido contacto estrecho en los 14 días previos con una persona que sea un caso probable o confirmado, deberán quedarse en su domicilio y contactar con los servicios de salud telefónicamente llamando al teléfono habilitado de tu Comunidad Autónoma, se pueden consultar en el siguiente enlace\n" +
                "\n" +
                "- Los servicios sanitarios valorarán su estado de salud y el antecedente de viaje y el posible contacto con casos de coronavirus\n" +
                "\n" +
                "- Los síntomas son fiebre, tos, fatiga, ¿han de presentarse a la vez?\n" +
                "\n" +
                "- No necesariamente. Los síntomas más comunes incluyen fiebre, que suele ser alta y de aparición repentina, tos, que suele ser seca, poco productiva y sensación de falta de aire."

        txt_virus_symptoms_indications.setText(text_Indications)
    }
}
