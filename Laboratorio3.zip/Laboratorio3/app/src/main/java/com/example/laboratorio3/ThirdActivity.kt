package com.example.laboratorio3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_third.*

class ThirdActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)


        var text_Symptoms: String = "Las formas de contagio conocidas son:\n" +
                "\n" +
                "- Contacto de persona a persona\n" +
                "\n" +
                "- Las gotículas llegan a nuestro sistema respiratorio a través de la tos o los estornudos de la persona infectada, según los expertos. Aunque, no necesariamente un estornudo o toser produce el contagio, ya que una simple conversación a corta distancia puede transmitir el virus.\n" +
                "\n" +
                "- Contacto por superfice: Si bien hay teorías de que el virus COVID-19 muere si no encuentra un organismo donde reproducirse, hay riesgo de que pueda aparecer en diferentes superficies donde sí han pasado personas con el coronavirus y hayan tocado dicho superficie. Por eso, hay que evitar encarecidamente llevarse la mano a la cara.\n" +
                "\n" +
                "- También hay que limpiar superficies de contacto frecuente para evitar que el virus aparezca allí. El lavado de manos también ayuda a esto. "


        txt_virus_symptoms_indications.setText(text_Symptoms)
    }
}
