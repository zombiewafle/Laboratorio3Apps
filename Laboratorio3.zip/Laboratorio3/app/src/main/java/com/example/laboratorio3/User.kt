package com.example.laboratorio3

data class User(var name: String = "", var age:Int = 0)