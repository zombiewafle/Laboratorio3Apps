package com.example.laboratorio3

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.example.laboratorio3.databinding.ActivityMainBinding
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var user = User("Usuario",0)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_main)
        binding.user = user


        val comentario = intent.getStringExtra("comentario")


        if(comentario != null && comentario !=""){
            Toast.makeText(applicationContext,R.string.comentario_vacio,Toast.LENGTH_LONG).show()
        }



        fun star(view: View){
            binding.apply {
                user?.name = edtName.text.toString()
                user?.age = edtAge.text.toString().toInt()


                var edad = edtAge.text.toString().toInt()
                var message = ""


                if ( edad in 0..15) {
                    message = "Esta en alto riesgo"
                    text_hide_and_apprear.setText(message)

                } else if (edad in 15..40) {
                    message = "No esta en riesgo"
                    text_hide_and_apprear.setText(message)

                } else if (edad in 41..59) {
                    message = "No esta en riesgo"
                    text_hide_and_apprear.setText(message)

                } else if (edad in 60..99) {
                    message = "Esta en alto riesgo"
                    text_hide_and_apprear.setText(message)

                } else {
                    Toast.makeText(applicationContext, R.string.edad_erronea, Toast.LENGTH_LONG).show()
                }

            }

        }


        binding.btnStar.setOnClickListener {
            star(it)

            if(binding.textHideAndApprear.visibility == View.VISIBLE){
                binding.edtAge.visibility = View.GONE
                binding.edtName.visibility = View.GONE
                binding.textAge.visibility = View.GONE
                binding.textName.visibility = View.GONE


            }else{
                binding.edtAge.visibility = View.VISIBLE
                binding.edtName.visibility = View.VISIBLE
                binding.textAge.visibility = View.VISIBLE
                binding.textName.visibility = View.VISIBLE
                binding.textHideAndApprear.visibility == View.GONE


            }
        }


        binding.btnVirus.setOnClickListener{
            val newIntent: Intent = Intent(this,SecondActivity::class.java)
            startActivity(newIntent)
            finish()
        }


        binding.btnSymptoms.setOnClickListener{
            val newIntent: Intent = Intent(this,ThirdActivity::class.java)
            startActivity(newIntent)
            finish()
        }


        binding.btnIndications.setOnClickListener{
            val newIntent: Intent = Intent(this,FourthActivity::class.java)
            startActivity(newIntent)
            finish()


        }
    }
}