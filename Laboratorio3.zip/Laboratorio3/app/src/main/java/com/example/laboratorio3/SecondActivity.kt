package com.example.laboratorio3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_second.*

class SecondActivity : AppCompatActivity() {
    private lateinit var binding: SecondActivity

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        val datosIntent: Intent = intent



        var text_Virus: String = "Los coronavirus son una familia de virus que se descubrió en la década de los 60 pero cuyo origen es todavía desconocido. Sus diferentes tipos provocan distintas enfermedades, desde un resfriado hasta un síndrome respiratorio grave (una forma grave de neumonía).\n" +
                "\n" +
                "Gran parte de los coronavirus no son peligrosos y se pueden tratar de forma eficaz. De hecho, la mayoría de las personas contraen en algún momento de su vida un coronavirus, generalmente durante su infancia. Aunque son más frecuentes en otoño o invierno, se pueden adquirir en cualquier época del año.\n" +
                "\n" +
                "El coronavirus debe su nombre al aspecto que presenta, ya que es muy parecido a una corona o un halo. Se trata de un tipo de virus presente sobre todo en los animales, pero también en los humanos. \n" +
                "\n" +
                "A finales de diciembre de 2019 se notificaron los primeros casos de un nuevo coronavirus en la ciudad de Wuhan (China). Desde entonces el aumento de nuevos infectados por el virus SARS-CoV-2 (inicialmente llamado 2019nCoV), que provoca la enfermedad denominada Covid-19, ha sido continuo y su transmisión de persona a persona se ha acelerado. Los casos declarados ya superan con creces a los de la epidemia de SARS de 2002-2003. Su tasa de letalidad es más baja, pero se están produciendo muchos más fallecimientos (rebasan los 100.000, según las cifras oficiales) porque las personas infectadas ya se cuentan por millones en todo el mundo."

        txt_virus_symptoms_indications.setText(text_Virus)
    }
}
